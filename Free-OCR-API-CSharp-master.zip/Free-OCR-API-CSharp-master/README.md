# Free-OCR-API-CSharp
Web API test app for the OCR.SPACE Free OCR API as Visual Studio C# project. 

Update May 11: Added support for sending PDF documents

For an ASP.NET example project see https://github.com/A9T9/Free-OCR-API-ASP.NET
