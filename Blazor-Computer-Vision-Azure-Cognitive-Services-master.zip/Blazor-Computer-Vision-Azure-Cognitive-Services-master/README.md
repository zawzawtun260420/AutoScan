# Blazor-Computer-Vision-Azure-Cognitive-Services

An Optical Character Recognition (OCR) app using Blazor and Azure Computer Vision Cognitive Services.

# Demo

![BlazorComputerVision](https://github.com/AnkitSharma-007/Blazor-Computer-Vision-Azure-Cognitive-Services/blob/master/Output/BlazorComputerVision.gif)

# Read the complete article
[Optical Character Reader Using Blazor And Computer Vision](https://ankitsharmablogs.com/optical-character-reader-using-blazor-and-computer-vision/)
